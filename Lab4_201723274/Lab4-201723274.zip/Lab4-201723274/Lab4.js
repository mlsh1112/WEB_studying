function   myFunction  (){
    let btn_node=document.querySelector('#append-text-button');
    var input=document.getElementById("text").value;
    let newart=document.createElement("article")
    newart.innerHTML=input;
    document.querySelector("#root").appendChild(newart)


    if(input){
        ++count;
    }

    document.getElementById("notecnt").innerHTML=count;



};





var count=0;
document.getElementById( 'append-text-button' ).addEventListener('click',  myFunction() );