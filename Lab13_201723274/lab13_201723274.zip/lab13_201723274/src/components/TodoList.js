import React, {Component} from 'react';
import List from './List'
import Form from "./Form";
import PropTypes from 'prop-types'
import {connect} from "react-redux";
import {deleteTodo, toggleTodo} from '../actions/todo'
let total = 0;
let done = 0;
function TodoList  ({ todos, toggleTodo })  {
    return(
    <div>
        <Form onClick={() => total++} />
        <span>Total : {total}  Done : {done} </span>
        <ul>
        {todos.map(todo =>
            <List
                key={todo.id}
                {...todo}
                onClick={() => {toggleTodo(todo.id)
                done++}}

            />
        )}
    </ul>
    </div>
    )
}
TodoList.propTypes = {
    todos: PropTypes.arrayOf(PropTypes.shape({
        id: PropTypes.number.isRequired,
        completed: PropTypes.bool.isRequired,
        text: PropTypes.string.isRequired
    }).isRequired).isRequired,
    toggleTodo: PropTypes.func.isRequired,
    deleteTodo: PropTypes.func.isRequired

}
const mapStateToProps = state => ({
    todos: state.todo
})

const mapDispatchToProps = dispatch => ({
    toggleTodo: id => dispatch(toggleTodo(id)),
    deleteTodo: text => dispatch(deleteTodo(text))
})

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(TodoList)