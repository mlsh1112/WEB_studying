import React from 'react';

function Header(){
    return(
        <h1>Lab13-201723274</h1>

    )
}

export default Header;