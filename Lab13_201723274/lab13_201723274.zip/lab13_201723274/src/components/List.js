import React, {Component} from 'react';
import PropTypes from 'prop-types'
import {deleteTodo} from "../actions/todo";
import {connect} from "react-redux";


const List = ({ onClick, completed, text , dispatch }) => (

    <div style={{
    backgroundColor: completed ? 'green' : 'none'
}}>
    <li >{text}</li>
        <button onClick={e=> {
            e.preventDefault();
            dispatch(deleteTodo(text));
        }}>Delete</button>
        <button onClick={onClick}>
            Done
        </button>
    </div>
)
List.propTypes = {
    onClick: PropTypes.func.isRequired,
    completed: PropTypes.bool.isRequired,
    text: PropTypes.string.isRequired
}
export default connect()(List)