import React from 'react'
import { connect } from 'react-redux'
import { createTodo } from '../actions/todo'
import PropTypes from 'prop-types'

const Form = ({ dispatch,onClick }) => {
    let input

    return (
        <div>
            <form onSubmit={e => {
                e.preventDefault()
                if (!input.value.trim()) {
                    return
                }
                dispatch(createTodo(input.value))
                input.value = ''
            }}>
                <input ref={node => input = node} />
                <button type="submit" onClick={onClick}>
                    Add
                </button>
            </form>
        </div>
    )
}

Form.propTypes = {
    onClick: PropTypes.func.isRequired
}

export default connect()(Form)
