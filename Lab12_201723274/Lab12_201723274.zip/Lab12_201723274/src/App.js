import './App.css';
import logo from './logo.svg';
import React, {Component} from 'react';
import ReactDOM from 'react-dom';
import {render} from "@testing-library/react";

export default class App extends Component{
    constructor(props) {
        super(props);
        this.state = {
            newName: null,
            btn:false
        }
    }

    updateNewTextValue = (event) =>{
        this.setState({newName:event.target.value});
    }
    createNew = () =>{
        this.setState({btn:true});
    }

    render(){
        const btn=this.state.btn;
        let ren=null;
        if(btn){
            ren=
                <header className="App-header">
                <img src={logo} className="App-logo" alt="logo"/>
                <p>
                    Hello, {this.state.newName}!
                </p>
            </header>
        }
        else {
            ren=
                <header className="App-header">
                    <h1> Who are you?</h1>
                    <input value={this.state.newName} onChange={this.updateNewTextValue}/>
                    <button onClick={this.createNew}>OK</button>
                </header>
        }
        return(
            <div>
                {ren}
            </div>
        )

    }
}


ReactDOM.render(
    <App />,
    document.getElementById('root')
);

