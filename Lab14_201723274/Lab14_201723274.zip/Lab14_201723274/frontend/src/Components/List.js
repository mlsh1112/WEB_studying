import React, {Component} from 'react';
import ReviewCard from "./ReviewCard";
class List extends Component {
    constructor(props) {
        super();
        this.state = { reviews: props.data};
    }
    deleteReviewById(id) {
        const { reviews } = this.state;
        this.setState({
            reviews: reviews.filter(review => review._id !== id)
        })

    }

    render() {
        return (
            <div>
                <h2>Review List</h2>
                {
                    this.props.data.map(review =>
                    <ReviewCard review={review} onDelete={this.deleteReviewById.bind(this)}/>
                    )
                }
            </div>
        );
    }
}

export default List;