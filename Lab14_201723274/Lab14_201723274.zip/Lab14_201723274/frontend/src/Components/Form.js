import React, {Component} from 'react';
import { withRouter } from 'react-router-dom';
class Form extends Component {
    constructor(props) {
        super(props);
        this.form = {
            movie_name: React.createRef(),
            review_content: React.createRef(),
            rate: React.createRef()
        };

    }
    async submit(){
        const data = {
            movie_name: this.form.movie_name.current.value,
            review_content: this.form.review_content.current.value,
            rate: this.form.rate.current.value
        }
        const echo_result = await this.props.onSubmit(data);
        console.log(echo_result);
        this.props.history.push("/");
    }

    async cancel(){
        this.props.history.goBack();
    }


    render() {
        return (
            <div>
                <h3>Movie Review Form</h3>
                <div>movie name</div>
                <input ref={this.form.movie_name} ></input>
                <div>review content</div>
                <input ref={this.form.review_content}></input>
                <div>rate</div>
                <input ref={this.form.rate}></input>
                <button onClick={this.submit.bind(this)}>Ok</button>
                <button onClick={this.cancel.bind(this)}>Cancel</button>
            </div>
        );
    }
}

export default withRouter(Form)