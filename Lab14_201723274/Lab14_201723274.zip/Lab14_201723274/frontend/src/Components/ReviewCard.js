import React, {Component} from 'react';
import request from "../lib/request";
import {stars} from '../lib/stars';
class ReviewCard extends Component {
    async deleteReview() {
        await request.deleteReview(this.props.review._id);
        this.props.onDelete(this.props.review._id);
    }
    render(props) {
        return (
            <div>
                {stars(this.props.review.rate)}
                <div>{this.props.review.movie_name}</div>
                <div>{this.props.review.review_content}</div>
                <button onClick={this.deleteReview.bind(this)}>Delete</button>
            </div>
        );
    }
}

export default ReviewCard;