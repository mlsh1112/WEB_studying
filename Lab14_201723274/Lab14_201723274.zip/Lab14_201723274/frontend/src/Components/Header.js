import React, {Component} from 'react';
import { Route, Link } from 'react-router-dom';

class Header extends Component {
    render() {
        return (
            <div>
                <h3>201723274</h3>
                <Link to='/'>Home</Link>
                <Link to='/review/new'>New</Link>
            </div>
        );
    }
}

export default Header;