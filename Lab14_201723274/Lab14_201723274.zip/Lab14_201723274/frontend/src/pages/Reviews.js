import React, {Component} from 'react';
import request from '../lib/request';
import List from "../Components/List";

class Reviews extends Component {
    constructor() {
        super();
        this.state = { reviews: [] };

    }
    
    async componentDidMount(){
        const review = await request.getReviews();
        this.state.reviews=review.data;
        this.setState(review.data);

    }
    render() {
        return (
            <div>
                {
                    this.state.reviews.length > 0 ?
                        <List data={this.state.reviews}/> : <div>NULL</div>
                }

            </div>
        );
    }
}

export default Reviews;