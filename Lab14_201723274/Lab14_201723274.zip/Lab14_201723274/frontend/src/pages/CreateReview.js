import React, {Component} from 'react';
import request, {createReviews} from "../lib/request";
import Form from "../Components/Form";
class CreateReview extends Component {
    render() {
        return (
            <div>
                <Form onSubmit={request.createReviews}/>
            </div>
        );
    }
}

export default CreateReview;