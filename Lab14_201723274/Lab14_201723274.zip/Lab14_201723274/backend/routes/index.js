var express = require('express');
var router = express.Router();
var cors=require('cors');
var Review=require("../models/review");
/* GET home page. */
router.get('/', cors(),async (req, res, next)=> {
  Review.find((err, info) => {
    if (err) {
      return res.status(400).send(err);
    }
    return res.status(200).json(info);
  });
})

router.post('/', cors(),function (req, res, next) { // create review
  const { movie_name, review_content, rate } = req.body;
  const review = new Review({
    movie_name: movie_name,
    review_content: review_content,
    rate: rate
  });

  review.save((err, info) => {
    if (err) {
      return res.status(400).send(err);
    }
    return res.status(200).json(info);
  });

});

router.delete('/:id', (req, res,next) => {
  Review.remove({ _id: req.params.id }, (err, result) => {
    if (err) {
      return next(err);
    }
    return res.json(result);
    res.redirect('/');
  });
});
module.exports = router;
