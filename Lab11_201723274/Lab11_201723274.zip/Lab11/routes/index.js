const Movie=require("../models/movie");
var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {

  Movie.find({}).then((movie)=>{
    res.render('index',{movie:movie});
  }).catch((err)=>{
    console.log(err);
  });

});


router.get('/newmovie',function(req,res,next){
  res.render('newmovie',{title:'Express'});
});
router.get('/admin',function(req,res,next){
  Movie.find({}).then((movie)=>{
    res.render('admin',{movie:movie});
  }).catch((err)=>{
    console.log(err);
  });
});

router.post('/delete/:id', (req, res, next)=>{
  Movie.deleteOne({_id : req.params.id}).then((result)=>{
    var response = {
      success : true
    }
    res.status(200).json(response);
  }).catch((err)=>{
    var response = {
      success : false
    }
    res.status(500).json(response);
  });
});

module.exports = router;
