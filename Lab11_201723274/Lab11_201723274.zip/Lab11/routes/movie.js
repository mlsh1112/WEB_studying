const Movie=require('../models/movie');
var express = require('express');
var router = express.Router();

/* GET users listing. */
router.post('/update/:id',function (req,res){
    Movie.findByIdAndUpdate(req.params.id, req.body, (err, movie)=>{
        console.log(movie);
        res.redirect('/admin');
    });
});

router.get('/read/:id',function (req,res){
    Movie.findById(req.params.id ).then((movie)=>{
        res.render('editmovie', {movie:movie});
    }).catch((err)=>{
        console.log(err);
    });
});
router.get('/delete/:id', (req, res, next)=>{
    Movie.deleteOne({_id : req.params.id}).then((result)=>{
        res.redirect("/admin");
    });
});

router.post('/ajaxdelete/:id', (req, res, next)=>{
    Movie.deleteOne({_id : req.params.id}).then((result)=>{
        var response = {
            success : true
        }
        res.status(200).json(response);
    }).catch((err)=>{
        var response = {
            success : false
        }
        res.status(500).json(response);
    });
});
router.post('/create', function(req, res, next) {
    const movie=new Movie({
        title:req.body.title,
        year:req.body.year,
        url:req.body.url
    });
    movie.save((err)=>{
        res.redirect('/');
    });
});


module.exports = router;
