function ajaxDelete(id) {
    var xhr = new XMLHttpRequest();

    xhr.onload = function () {
        if (xhr.status === 200 || xhr.status === 201) {
            document.getElementById('movie' + id).remove()
            alert("삭제 성공!");
        } else {
            alert("삭제 실패");
        }
    }

    xhr.open("POST", "/movie/ajaxdelete/" + id)
    xhr.setRequestHeader("Content-Type", 'application/json');
    xhr.send();

}